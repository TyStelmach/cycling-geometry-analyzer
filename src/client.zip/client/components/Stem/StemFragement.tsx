import { FunctionComponent } from 'preact';
import { useEffect, useRef } from 'preact/hooks';

const StemFragment: FunctionComponent<StemFragmentProps> = ({
  config,
  position,
  scale,
  x,
  y,
  rotation = 0,
  parentRotation = 0,
  parentY = 0,
  updateStemCoords,
}) => {
  const groupRef = useRef<SVGGElement>(null);
  let transformationMatrix = new DOMMatrix();
  let topConnectionCoords = new DOMPoint();
  let bottomConnectionCoords = new DOMPoint();

  const diagramConfig = position === 'collar' ? config.diagrams.collar : config.diagrams.face;
  const svgBaseWidth = position === 'collar' ? config.collarLength : config.faceLength;
  const svgBaseHeight = config.exactHeight;

  const width = svgBaseWidth * scale;
  const height = svgBaseHeight * scale;

  const adjustedXAxis = x - (width / 2);
  const adjustedYAxis = y - (height / 2);

  // Calculate the effective rotation
  const effectiveRotation = position === 'face'
    ? -parentRotation + rotation
    : rotation;

  // Calculate the vertical offset due to stem angle
  const stemAngleOffset = (parentY - y) * Math.tan(parentRotation * Math.PI / 180);

  useEffect(() => {
    if (!groupRef.current) return;

    // Create a transformation matrix that combines all the required transformations
    transformationMatrix = new DOMMatrix()
      .translate(adjustedXAxis, adjustedYAxis)
      .rotate(effectiveRotation, width / 2, height / 2);

    // Transform the connection point coordinates using the transformation matrix
    topConnectionCoords = new DOMPoint(
      width * (diagramConfig.connections.top.x / 100),
      height * (diagramConfig.connections.top.y / 100)
    ).matrixTransform(transformationMatrix);

    bottomConnectionCoords = new DOMPoint(
      width * (diagramConfig.connections.bottom.x / 100),
      height * (diagramConfig.connections.bottom.y / 100)
    ).matrixTransform(transformationMatrix);

    const stemDebugCoords = {
      top: {
        x: topConnectionCoords.x,
        y: topConnectionCoords.y + stemAngleOffset
      },
      bottom: {
        x: bottomConnectionCoords.x,
        y: bottomConnectionCoords.y + stemAngleOffset
      }
    };

    updateStemCoords(stemDebugCoords);
  }, [
    adjustedXAxis,
    adjustedYAxis,
    width,
    height,
    diagramConfig,
    updateStemCoords,
    effectiveRotation,
    stemAngleOffset
  ]);

  return (
    <g ref={groupRef} transform={`translate(${adjustedXAxis},${adjustedYAxis}) rotate(${effectiveRotation} ${width / 2} ${height / 2})`}>
      <image
        href={diagramConfig.path}
        width={width}
        height={height}
      />

      <circle
        cx={topConnectionCoords.x}
        cy={topConnectionCoords.y + stemAngleOffset}
        r={2}
        fill="red"
      />
      <circle
        cx={bottomConnectionCoords.x}
        cy={bottomConnectionCoords.y + stemAngleOffset}
        r={2}
        fill="red"
      />
    </g>
  );
};

export default StemFragment;