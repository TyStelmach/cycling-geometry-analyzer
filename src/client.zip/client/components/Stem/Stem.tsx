import { FunctionComponent } from 'preact';
import { useState, useEffect } from 'preact/hooks';
import { calculateStackOffset, calculateStemCoords } from '../../utils/calculations';
import StemFragment from './StemFragement';

const Stem: FunctionComponent = ({
  stem,
  frame,
  config,
  gridSize,
  gridCenter,
  gridRatio
}) => {
  const [collarDebugCoords, setCollarDebugCoords] = useState({ top: { x: 0, y: 0 }, bottom: { x: 0, y: 0 } });
  const [faceDebugCoords, setFaceDebugCoords] = useState({ top: { x: 0, y: 0 }, bottom: { x: 0, y: 0 } });

  const stemCoords = calculateStemCoords(stem, gridCenter);
  const stemStackOffset = calculateStackOffset(stem.stackHeight, frame.headtubeAngle);
  const stemRotationAngle = frame.headtubeAngle - 90;
  const compositeTransformation = `translate(${stemStackOffset.x} ${stemStackOffset.y}) rotate(${stemRotationAngle} ${stemCoords.collar.center.x} ${stemCoords.collar.center.y})`;
  const totalRotation = stemRotationAngle + stem.angle;

  return (
    <g transform={compositeTransformation}>

      <line
        x1={stemCoords.collar.center.x}
        y1={0}
        x2={stemCoords.collar.center.x}
        y2={gridSize}
        stroke="#0066cc"
        strokeWidth={2}
        strokeDasharray="8 4"
      />

    <path
        d={`M ${collarDebugCoords.top.x} ${collarDebugCoords.top.y} 
            L ${faceDebugCoords.top.x} ${faceDebugCoords.top.y}
            M ${collarDebugCoords.bottom.x} ${collarDebugCoords.bottom.y}
            L ${faceDebugCoords.bottom.x} ${faceDebugCoords.bottom.y}`}
        stroke={'#000000'}
        strokeWidth={2}
        fill="none"
      />

      <StemFragment
        config={config}
        position="collar"
        scale={gridRatio}
        x={stemCoords.collar.center.x}
        y={stemCoords.collar.center.y}
        updateStemCoords={setCollarDebugCoords}
      />

      <StemFragment
        config={config}
        position="face"
        scale={gridRatio}
        x={stemCoords.face.center.x}
        y={stemCoords.face.center.y}
        rotation={-totalRotation} // Negative of the total rotation
        updateStemCoords={setFaceDebugCoords}
      />
    </g>
  )
}

export default Stem;